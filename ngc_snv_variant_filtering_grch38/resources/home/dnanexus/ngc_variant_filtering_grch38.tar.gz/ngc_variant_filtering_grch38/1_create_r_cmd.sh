#!/bin/bash
#!
## date: 2020-8-2
## project name: 20200801
## pipeline version: 1.0
## genome version: grch38

mkdir -p /home/dnanexus/ngc_variant_filtering_grch38/output
mkdir -p /home/dnanexus/ngc_variant_filtering_grch38/log

# Folders Paths
WorkDir="/home/dnanexus/ngc_variant_filtering_grch38"
Config="/home/dnanexus/ngc_variant_filtering_grch38/config"
Genes="/home/dnanexus/ngc_variant_filtering_grch38/genes"
Annot="/home/dnanexus/ngc_variant_filtering_grch38/input"
TrioFilterOut="/home/dnanexus/ngc_variant_filtering_grch38/output"
Log="/home/dnanexus/ngc_variant_filtering_grch38/log"


########## START: Family Filtering #############

echo "Started"

# create shell script to run R commands
echo "#!/bin/bash" > $WorkDir/2_run_r_cmd.sh

# read trio in loop and make R commands
for i in `cut -f1 -d' ' $Config/extrFamAll.txt`;do echo "Rscript $WorkDir/familyFiltering.v7.R --vars $Annot/input.annot.tab --ped $Config/manifest.txt --family $i --genelist $Genes/NGC_genelist_allNamesOnly-20200519.txt --pheno . --hpodb $Genes/phenotype_to_genes.txt  --omim $Genes/omim_20200421_geneInfoBase.txt --columns $Config/columns.v3_grch38.txt --haem_genes $Genes/haem_somatic_mosaicism_genes_20191015.txt --imprinted_genes $Genes/imprinted_genes_20200424.txt --poly_genes $Genes/polymorphic_genes_20200509.txt --freq_script _grch38 --out $TrioFilterOut/Fam_filter.${i}.filt.txt 2>&1 | tee $Log/Fam_filter.$i.log" >> $WorkDir/2_run_r_cmd.sh;done

############# END ###############

chmod 777 $WorkDir/2_run_r_cmd.sh

# run r commands
$WorkDir/2_run_r_cmd.sh






